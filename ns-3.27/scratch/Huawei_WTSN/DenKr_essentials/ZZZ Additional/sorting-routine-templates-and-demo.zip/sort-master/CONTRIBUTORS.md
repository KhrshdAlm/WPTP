List of contributors, in alphabetical order:


 - Andrey Astrelin
 - Antony Dovgal
 - Christopher Swenson
 - [@drfie](https://github.com/drfie)
 - Google Inc.
 - Haneef Mubarak
 - Vojtech Fried
 - Matthieu Darbois
